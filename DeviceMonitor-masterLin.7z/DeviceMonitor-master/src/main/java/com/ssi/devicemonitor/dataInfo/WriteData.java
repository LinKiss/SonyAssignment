package com.ssi.devicemonitor.dataInfo;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import com.ssi.devicemonitor.entity.Device;
import com.ssi.devicemonitor.entity.GeneralDevice;
import com.ssi.devicemonitor.entity.HardwareDevice;
import com.ssi.devicemonitor.entity.SoftwareDevice;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class WriteData {

    @SuppressWarnings("unchecked")
    public void write( List<Device> devices )
    {
        //Add devices to the list
        JSONArray devicesList = new JSONArray();

        for ( Device device: devices ) {
            JSONObject deviceProperties = new JSONObject();
            deviceProperties.put("name", device.getName());
            deviceProperties.put("status", device.getStatus());
            deviceProperties.put("deviceType", ((GeneralDevice)device).getDeviceType());
            deviceProperties.put("manufacturer", ((GeneralDevice)device).getManufacturer());
            deviceProperties.put("version", ((GeneralDevice)device).getVersion());

            if (((GeneralDevice) device).isHardware()) {
                deviceProperties.put("location", ((HardwareDevice) device).getLocation());
                deviceProperties.put("macAddress", ((HardwareDevice) device).getMacAddress());
            }
            else if (((GeneralDevice) device).isSoftware()) {
                    deviceProperties.put("installationTime", ((SoftwareDevice) device).getInstallationTime());
            }

            JSONObject deviceObject = new JSONObject();
            deviceObject.put("device", deviceProperties);

            devicesList.add(deviceObject);
        }

        //Write JSON file
        try (FileWriter file = new FileWriter("devices.json")) {
            file.write(devicesList.toJSONString());
            file.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
