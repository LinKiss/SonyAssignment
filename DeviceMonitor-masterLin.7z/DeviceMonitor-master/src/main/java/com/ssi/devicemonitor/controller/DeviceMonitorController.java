package com.ssi.devicemonitor.controller;

import com.ssi.devicemonitor.dataInfo.WriteData;
import com.ssi.devicemonitor.entity.*;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.FlowPane;

import java.security.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.*;

public class DeviceMonitorController {
    @FXML
    private ListView<Device> deviceListView;

    @FXML
    private TextField deviceNameTextField;

    @FXML
    private ComboBox deviceTypeComboBox;

    @FXML
    private Button addDeviceButton;

    @FXML
    private Button editDeviceButton;

    @FXML
    private FlowPane generalPropertiesPane;

    @FXML
    private FlowPane softwarePropertiesPane;

    @FXML
    private FlowPane hardwarePropertiesPane;

    @FXML
    private TextField manufacturerTF;

    @FXML
    private ComboBox deviceTypeCB;

    @FXML
    private TextField versionTF;

    @FXML
    private TextField locationTF;

    @FXML
    private TextField macAddressTF;

    @FXML
    private TextField installationTF;

    @FXML
    private Button saveDevicesButton;

    @FXML
    private Button loadDevicesButton;

    private DeviceMonitor deviceMonitor;


    public void initialize() {
        deviceMonitor = new DeviceMonitor();

        deviceMonitor.addDevice(new GeneralDevice("Device 1"));
        deviceMonitor.addDevice(new GeneralDevice("Device 2"));
        deviceMonitor.addDevice(new GeneralDevice("Device 3"));

        deviceListView.setItems(FXCollections.observableList(deviceMonitor.getDevices()));
        deviceListView.setCellFactory(deviceListView -> new DeviceListCell());

        //deviceTypeComboBox = new ComboBox(FXCollections.observableArrayList(GeneralDevice.DeviceType.values()));
        deviceTypeComboBox.getItems().add("");
        deviceTypeComboBox.getItems().addAll(GeneralDevice.DeviceType.values());
        //deviceTypeComboBox.setValue(deviceTypeComboBox.getItems().get(0));

        generalPropertiesPane.getChildren().add(new Label("Device Type: "));
        generalPropertiesPane.getChildren().add(deviceTypeCB);
        generalPropertiesPane.getChildren().add(new Label("Manufacturer: "));
        generalPropertiesPane.getChildren().add(manufacturerTF);
        generalPropertiesPane.getChildren().add(new Label("Version: "));
        generalPropertiesPane.getChildren().add(versionTF);
        softwarePropertiesPane.getChildren().add(generalPropertiesPane);
        hardwarePropertiesPane.getChildren().add(generalPropertiesPane);
        softwarePropertiesPane.getChildren().add(new Label("Installation Time: "));
        softwarePropertiesPane.getChildren().add(installationTF);
        hardwarePropertiesPane.getChildren().add(new Label("Location: "));
        hardwarePropertiesPane.getChildren().add(locationTF);
        hardwarePropertiesPane.getChildren().add(new Label("MAC Address: "));
        hardwarePropertiesPane.getChildren().add(macAddressTF);

        generalPropertiesPane.getChildren().add(editDeviceButton);

        softwarePropertiesPane.setVisible(false);
        hardwarePropertiesPane.setVisible(false);

        // Add context menu to ListView
        ContextMenu contextMenu = new ContextMenu();
        MenuItem removeItem = new MenuItem("Remove");
        MenuItem displayProperties = new MenuItem("Display Properties");
        MenuItem editProperties = new MenuItem("Edit Properties");

        removeItem.setOnAction(event -> {
            Device selectedDevice = deviceListView.getSelectionModel().getSelectedItem();
            if (selectedDevice != null) {
                deviceMonitor.removeDevice(selectedDevice);
                refreshListView();
            }
        });

        displayProperties.setOnAction(event -> {
            Device selectedDevice = deviceListView.getSelectionModel().getSelectedItem();
            if (selectedDevice != null) {
                manufacturerTF.setText(((GeneralDevice) selectedDevice).getManufacturer());
                if (((GeneralDevice) selectedDevice).hasDeviceType())
                    deviceTypeCB.setValue(((GeneralDevice) selectedDevice).getDeviceType().toString());
                versionTF.setText(String.valueOf(((GeneralDevice) selectedDevice).getVersion()));
                if (((GeneralDevice) selectedDevice).isHardware()) {
                    hardwarePropertiesPane.setVisible(true);
                    softwarePropertiesPane.setVisible(false);
                    locationTF.setText(((HardwareDevice) selectedDevice).getLocation());
                    macAddressTF.setText(((HardwareDevice) selectedDevice).getMacAddress());
                } else if (((GeneralDevice) selectedDevice).isSoftware()) {
                    softwarePropertiesPane.setVisible(true);
                    hardwarePropertiesPane.setVisible(false);
                    installationTF.setText(((SoftwareDevice) selectedDevice).getInstallationTime().toString());
                } else {
                    softwarePropertiesPane.setVisible(false);
                    hardwarePropertiesPane.setVisible(false);
                }
            }
        });

        editProperties.setOnAction(event -> {
            Device selectedDevice = deviceListView.getSelectionModel().getSelectedItem();
            if (selectedDevice != null) {
                // open new dialog with all the relevant properties
            }
        });

        contextMenu.getItems().addAll(removeItem);
        contextMenu.getItems().addAll(displayProperties);
        contextMenu.getItems().addAll(editProperties);
        deviceListView.setContextMenu(contextMenu);

    }

    private class DataUpdateTask extends TimerTask {
        private Random random = new Random();

        @Override
        public void run() {
            refreshListView();
        }
    }

    @FXML
    private void editDevice() {
        Device selectedDevice = deviceListView.getSelectionModel().getSelectedItem();
        if (selectedDevice != null) {
            ((GeneralDevice)selectedDevice).setManufacturer(manufacturerTF.getText());
            ((GeneralDevice)selectedDevice).setDeviceType(GeneralDevice.DeviceType.valueOf(deviceTypeCB.getValue().toString()));
            ((GeneralDevice)selectedDevice).setVersion(Integer.valueOf(versionTF.getText()));
            if (((GeneralDevice) selectedDevice).isHardware()) {
                ((HardwareDevice)selectedDevice).setLocation(locationTF.getText());
                ((HardwareDevice)selectedDevice).setMacAddress(macAddressTF.getText());
            }
            else if (((GeneralDevice) selectedDevice).isSoftware()) {
                try {
                    SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
                    Date parsedDate = dateFormat.parse(installationTF.getText());
                    ((SoftwareDevice) selectedDevice).setInstallationTime(new Date(parsedDate.getTime()));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            macAddressTF.clear();
            locationTF.clear();
            installationTF.clear();
            manufacturerTF.clear();
            deviceTypeCB.setValue("");
            versionTF.clear();
        }
    }

    @FXML
    private void saveData() {
       deviceMonitor.saveData();
    }

    @FXML
    private void loadData() {
        deviceMonitor.loadData();
    }

    @FXML
    private void addDevice() {
        String deviceName = deviceNameTextField.getText();
        if (!deviceName.isEmpty()) {
            GeneralDevice.DeviceType deviceType = null;
            if (deviceTypeComboBox != null && deviceTypeComboBox.getValue() != null && !"".equals(deviceTypeComboBox.getValue()))
                deviceType = GeneralDevice.DeviceType.valueOf(deviceTypeComboBox.getValue().toString());
            Device newDevice;
            if (GeneralDevice.DeviceType.Hardware.equals(deviceType))
                newDevice = new HardwareDevice(deviceName, deviceType);
            else if (GeneralDevice.DeviceType.Software.equals(deviceType))
                newDevice = new SoftwareDevice(deviceName, deviceType);
            else
                newDevice = new GeneralDevice(deviceName);
            deviceMonitor.addDevice(newDevice);
            deviceNameTextField.clear();
            refreshListView();
        }
        else {
            // TODO: display error message
        }
    }

    public void refreshListView() {
        deviceListView.refresh();
    }

    private class DeviceListCell extends ListCell<Device> {
        @Override
        protected void updateItem(Device device, boolean empty) {
            super.updateItem(device, empty);

            if (device == null || empty) {
                setText(null);
                setGraphic(null);
                setStyle(""); // Reset the cell style
            } else {
                setText(device.getName() + " - " + device.getStatus());

                // Set the cell style based on the device status
                if (device.getStatus().equals("Online")) {
                    setStyle("-fx-text-fill: green;");
                } else if (device.getStatus().equals("Offline")) {
                    setStyle("-fx-text-fill: red;");
                } else {
                    setStyle(""); // Reset the cell style
                }
            }
        }
    }
}
