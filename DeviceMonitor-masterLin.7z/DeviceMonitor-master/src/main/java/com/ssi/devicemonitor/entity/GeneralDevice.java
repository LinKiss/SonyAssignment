package com.ssi.devicemonitor.entity;

public class GeneralDevice extends Device {
    public enum DeviceType {
        Hardware("Hardware"), Software("Software");

        private final String name;
        DeviceType(String hardware) {
            name = hardware;
        }
    }
    private String manufacturer;
    private DeviceType deviceType;
    private int version;

    public GeneralDevice(String name) {
        super(name);
    }

    public GeneralDevice(String name, DeviceType deviceType) {
        this(name);
        this.deviceType = deviceType;
    }

    public boolean isHardware() {
        if (DeviceType.Hardware.equals(deviceType))
            return true;
        return false;
    }

    public boolean isSoftware() {
        if (DeviceType.Software.equals(deviceType))
            return true;
        return false;
    }
    public boolean hasDeviceType() {
        if (deviceType == null)
            return false;
        return true;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public DeviceType getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(DeviceType deviceType) {
        this.deviceType = deviceType;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }
}
