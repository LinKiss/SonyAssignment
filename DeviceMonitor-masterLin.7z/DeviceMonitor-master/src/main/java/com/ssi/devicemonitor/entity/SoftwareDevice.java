package com.ssi.devicemonitor.entity;


import java.util.Date;

public class SoftwareDevice extends GeneralDevice {
    private Date installationTime;

    public SoftwareDevice(String name, DeviceType deviceType) {
        super(name, deviceType);
        installationTime = new Date();
    }

    public Date getInstallationTime() {
        return installationTime;
    }

    public void setInstallationTime(Date installationTime) {
        this.installationTime = installationTime;
    }
}
