package com.ssi.devicemonitor.entity;

public class HardwareDevice extends GeneralDevice {
    private String location;
    private String macAddress;

    public HardwareDevice(String name, DeviceType deviceType) {
        super(name, deviceType);
        location = null;
        macAddress = null;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getMacAddress() {
        return macAddress;
    }

    public void setMacAddress(String macAddress) {
        this.macAddress = macAddress;
    }
}
