package com.ssi.devicemonitor.dataInfo;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.ssi.devicemonitor.entity.Device;
import com.ssi.devicemonitor.entity.GeneralDevice;
import com.ssi.devicemonitor.entity.HardwareDevice;
import com.ssi.devicemonitor.entity.SoftwareDevice;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class ReadData
{

    @SuppressWarnings("unchecked")
    public List<Device> read()
    {
        List<Device> devices = new ArrayList<>();

        //JSON parser object to parse read file
        JSONParser jsonParser = new JSONParser();

        try (FileReader reader = new FileReader("devices.json"))
        {
            //Read JSON file
            Object obj = jsonParser.parse(reader);

            JSONArray devicesList = (JSONArray) obj;
            System.out.println(devicesList);

            //Iterate over device array
            for (Object deviceObj : devicesList) {
                Device device = parseDeviceObject( (JSONObject) deviceObj );
                devices.add(device);
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return devices;
    }

    private static Device parseDeviceObject(JSONObject deviceInObj)
    {
       //Get device object within list
        JSONObject deviceObject = (JSONObject) deviceInObj.get("device");

        Device device = new GeneralDevice((String) deviceObject.get("name"));
        device.setStatus((String) deviceObject.get("status"));
        if (((GeneralDevice)device).hasDeviceType())
            ((GeneralDevice)device).setDeviceType(GeneralDevice.DeviceType.valueOf(deviceObject.get("deviceType").toString()));
        ((GeneralDevice)device).setManufacturer((String) deviceObject.get("manufacturer"));
        ((GeneralDevice)device).setVersion(Integer.valueOf(deviceObject.get("version").toString()));

        if (((GeneralDevice) device).isHardware()) {
            ((HardwareDevice) device).setLocation((String) deviceObject.get("location"));
            ((HardwareDevice) device).setMacAddress((String) deviceObject.get("macAddress"));
        }
        else if (((GeneralDevice) device).isSoftware()) {
            ((SoftwareDevice) device).setInstallationTime((Date) deviceObject.get("installationTime"));
        }
        return device;
    }
}
