module com.ssi.devicemonitor {
    requires javafx.controls;
    requires javafx.fxml;
    requires json.simple;

    opens com.ssi.devicemonitor.controller to javafx.fxml;

    exports com.ssi.devicemonitor;
}
